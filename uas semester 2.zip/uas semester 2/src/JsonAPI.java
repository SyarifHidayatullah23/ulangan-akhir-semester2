import model.covidstatus;
import network.conecturi;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class JsonAPI {
    public static void main(String[] args) throws IOException {
        String nama;
        String usia;
        String alamat;
        String Phone;
        String variancovid;


        ArrayList<covidstatus> _covid = new ArrayList<>();
        try {
            covidstatus s = new covidstatus();
            Scanner _input = new Scanner(System.in);
            System.out.print("Masukkan nama      : ");
            nama = _input.nextLine();
            System.out.print("Masukkan usia     : ");
            usia = _input.nextLine();
            System.out.print("Masukkan alamat  : ");
            alamat = _input.nextLine();
            System.out.print("Masukkan Phone    : ");
            Phone = _input.nextLine();
            System.out.println("Masukan variancovid");
            variancovid = _input.nextLine();

            s.set_nama(nama);
            s.set_usia(usia);
            s.set_alamat(alamat);
            s.set_phone(Phone);
            s.set_variancovid(variancovid);
            _covid.add(s);

        } catch (Exception e){
            e.printStackTrace();
        }

        for (int j = 0;j<_covid.size();j++){
            System.out.println(_covid.get(j).get_nama() + " - " + _covid.get(j).get_usia() + " - " +
                    _covid.get(j).get_alamat() + " - " + _covid.get(j).get_phone() + " - ");
        }

        //mengubah Arraylist menjadi format JSON

        JSONArray jsonStudent = new JSONArray();
        JSONObject myJObject = new JSONObject();
        myJObject.put("nim",_covid.get(0).get_nama());
        myJObject.put("name",_covid.get(0).get_usia());
        myJObject.put("address",_covid.get(0).get_alamat());
        myJObject.put("phone",_covid.get(0).get_phone());
        jsonStudent.put(myJObject);

        System.out.println(jsonStudent.toString());

        //Send Student data to data cloud
        conecturi myUriBuilder = new conecturi();
        URL myAdrress = myUriBuilder.buildURL("https://harber.mimoapps.xyz/fromjava.php");
        myUriBuilder.postJSON(myAdrress,jsonStudent.toString());

    }
}
