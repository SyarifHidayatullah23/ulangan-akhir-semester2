package model;

public class covidstatus {

    private String _nama;

    public int get_period() {
        return _period;
    }

    public void set_period(int _period) {
        this._period = _period;
    }

    public String get_variancovid() {
        return _variancovid;
    }

    public void set_variancovid(String _variancovid) {
        this._variancovid = _variancovid;
    }

    public String get_phone() {
        return _phone;
    }

    public void set_phone(String _phone) {
        this._phone = _phone;
    }

    private String _usia;

    public String get_usia() {
        return _usia;
    }

    public void set_usia(String _usia) {
        this._usia = _usia;
    }

    public String get_nama() {
        return _nama;
    }

    public void set_nama(String _nama) {
        this._nama = _nama;
    }

    public String get_alamat() {
        return _alamat;
    }

    public void set_alamat(String _alamat) {
        this._alamat = _alamat;
    }

    private String _alamat;
    private String _phone;
    private String _variancovid;
    private int _period;
}
